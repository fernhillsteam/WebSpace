/*
Powered by ly200.com		http://www.ly200.com
广州联雅网络科技有限公司		020-83226791
*/

var Ly200JsLang={
    _date:{
        _months:{
            _0:'JAN',
            _1:'FEB',
            _2:'MAR',
            _3:'APR',
            _4:'MAY',
            _5:'JUN',
            _6:'JUL',
            _7:'AUG',
            _8:'SEP',
            _9:'OCT',
            _10:'NOV',
            _11:'DEC'
        },
        _weeks:{
            _0:'SUN',
            _1:'MON',
            _2:'TUR',
            _3:'WED',
            _4:'THU',
            _5:'FRI',
            _6:'SAT'
        },
        _clear:'CLS',
        _today:'TODAY',
        _close:'CLOSE'
    },
    _windows:{
        _tips:'Tips',
        _close:'Close'
    }
};