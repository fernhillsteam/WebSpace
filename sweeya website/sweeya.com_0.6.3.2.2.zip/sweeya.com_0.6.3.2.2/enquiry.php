<!DOCTYPE html>
<html>

<!-- Mirrored from int.siglent.com/account.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Apr 2022 07:12:51 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	
<meta name="keywords" content="Oscilloscope,Waveform Generator" />
<meta name="description" content="Contact Us - Sweeya Tech Solutions" />
<title>Sweeya Tech Solutions</title>
<meta name="renderer" content="webkit" />
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<meta content="telephone=no" name="format-detection" /><link href="css/global.css" rel="stylesheet" type="text/css" />
<link href="css/lib.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />

<link href="css/style_en.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/lang/en.js"></script>
<script type="text/javascript" src="js/global.js"></script>
<script type="text/javascript" src="js/checkform.js"></script>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>

<!-- <script type="text/javascript" src="/js/wow.min.js"></script> -->
<link href="css/animated.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">

<script type="text/javascript" src="js/countUp.js"></script>

<script type="text/javascript" src="js/jquery.lazyload.min.js"></script>

<script type="text/javascript" src="js/iscroll.js"></script>

<!-- Owl Carousel Assets -->
<link href="owl/owl.carousel.css" rel="stylesheet">
<link href="owl/owl.theme.css" rel="stylesheet">
<script src="owl/owl.carousel.js"></script>

<script src="js/buttonLite.js"></script>
<script src="js/bshareC0.js"></script>

<!-- swiper -->
<script src="js/swiper.jquery.min.js"></script>
<link href="css/swiper.min.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/web.js"></script>

<link rel="shortcut icon " type="images/x-icon" href="images/sweeya.png">
<link rel="stylesheet" type="text/css" href="css/style2.css">

<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

<link rel="stylesheet" type="text/css" href="css/style2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="css/style3.css">
<style type="text/css">
    .account-wrap{background: url(u_file/sky.png) no-repeat center/cover;padding: 50px 0;}
</style>

<script>
$(function(){
	// var wow=new WOW().init();
})
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-44783891-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-44783891-3');
</script>
<style type="text/css">
    ::placeholder {
  font-style: italic;
  font-weight: 500;
  font-size: 1.3em;
  color: mintcream;
}



p.groove {
    font-size: 22px;
    } 
</style>

<script type="text/javascript">

console.log("Window Location:", window.location);
    
var myKeysValues = window.location.search;
console.log("Keys & Values:", myKeysValues);

var urlParams = new URLSearchParams(myKeysValues);

var param1 = urlParams.get('product_name');




/*console.log("Name:", param1);*/

/*document.getElementsByTagName("demo").value = param1;*/
/*document.getElementByTagName("demo").innerHTML = Object.values(param1);*/








/*var pro =*/ 

/*document.getElementById("product").innerHTML = 'param1';*/


/*function myFunction(){
document.getElementById("product").value = 'param1';    
}*/



</script>
</head>

<body>
	<!-- header start -->
   <header>
     <a href="index.html" class="logo"><img src="images/sweeya.png" width="120px" height="60px"></a>
      <nav class="navbar">
        <ul>
          <!-- <li><a href="index.html">Home</a></li> -->
          <li><a href="#">Product&nbsp;<i class="fa fa-angle-down" aria-hidden="true"></i></a>
              <ul style="width: 220px;">
                <li><a href="#">AC PowerSupplies</a></li>
                <li><a href="#">DC PowerSupplies</a></li>
                <li><a href="#">Electronic Loads</a></li>
                <li><a href="#">LCR Meter</a></li>
                <li><a href="#">Multimeters</a></li>
                <li><a href="#">Oscilloscopes</a></li>
                <li><a href="#">Safety Testers</a></li>
                <li><a href="#">Signal Generators</a></li>
                <li><a href="#">Spectrum Analysers</a></li>
                <li><a href="#">Vector Network Analysers</a></li>
                <li><a href="#">Other Meters</a></li>
                <li><a href="#">Accessories</a></li>             
              </ul>
          </li>
          <li><a href="about.html">About Us</a></li>
          <li><a href="#">Partners&nbsp;<i class="fa fa-angle-down" aria-hidden="true"></i></a>
              <ul class="bolt">
                <li><a id="right" href="partners/siglent/index.html" target="_blank">Siglent</a></li>
                <li><a id="right" href="partners/twintex/index.html" target="_blank">Twintex</a></li>
                <li><a id="right" href="partners/tonghui/index.html" target="_blank">Tonghui</a></li>
                <li><a id="right" href="partners/maynuo/index.html" target="_blank">Maynuo</a></li>
                <li><a id="right" href="partners/tenmar/index.html" target="_blank">Tenmars</a></li>

              </ul> 
          </li>
          <li><a href="careers.html">Careers</a></li>
          <li><a href="news.html">News & Events</a></li>
          <li><a href="contact.html">Contact Us</a></li>

        </ul>
      </nav>
   </header>
<!-- header end -->

<!-- header-mobile-start -->
<div id="header-mobile" class="">
    <div class="mobile-wrap">
        <div class="left fl">
            <a href="index.html"><img src="u_file/weblogo/sweeya.png" alt="SWEEYA"></a>
        </div>
        <div class="right fr">
            <form action="https://int.siglent.com/search/" method="get" class="sides top-search clean fl over trans relative stopP" OnSubmit="return checkForm(this);">
                <input type="text" class="text trans fr" name="Keyword" value="" placeholder="Search..." check="Please fill in the keywords! ~*">
                <input type="submit" class="button absolute" value="">
                <input type="hidden" name="jump_url" value="../../index0880.html?u=products-overview%2Fsdg800%2F">
                <a href="javascript:;" class="absolute"></a>
            </form>
            <a href="javascript:;" class="mobilenav">
                <img src="images/m2.png">
            </a>
        </div>
        <div class="clear"></div>
    </div>
    <div class="header-mobile">
        <div class="top">
            
            <div class="right fr">
                <a href="javascript:;" class="closes">
                    <img src="images/close.png">
                </a>
            </div>
            <div class="clear"></div>
        </div>
        <div class="nav">
            <ul>
                 <li>
                    <a href="/index.html" class="bignav1"s >Home</a>

                
                </li>
                <li>

                    <a href="javascript:;" class="bignav1">Products</a>
          
                </li>
                 <li>

                    <a href="javascript:;" class="bignav">Oscilloscopes</a>
                    <div class="header2">          
                                                        <a href="products-overview/sds2000series/index.html" class="navs trans pro">
                                SDS2000 series                            </a>
                                                        <a href="products-overview/sds1000cflseries/index.html" class="navs trans pro">
                                SDS1000CFL series                            </a>
                                                        <a href="products-overview/sds1000cml/index.html" class="navs trans pro">
                                SDS1000CML                            </a>
                                                        <a href="products-overview/sds1000cnl/index.html" class="navs trans pro">
                                SDS1000CNL                            </a>
                                                        <a href="products-overview/sds1000dl/index.html" class="navs trans pro">
                                SDS1000DL 
                                                                      </a>
                                            </div>


                </li> <li>

                    <a href="javascript:;" class="bignav">Hand-held Oscilloscopes</a>
                    <div class="header2">          
                                                        <a href="products-overview/shs1000series/index.html" class="navs trans pro">
                                SHS 1000 Series                            </a>
                                                        <a href="products-overview/shs800series/index.html" class="navs trans pro">
                                SHS 800 Series                            </a>
                                            </div>

                </li> <li>

                    <a href="javascript:;" class="bignav1">Signal Sources</a>



                </li>
                 <li>

                    <a href="javascript:;" class="bignav">Power Supplies</a>
                    <div class="header2">          
                                                        <a href="products-overview/spd3303ds/index.html" class="navs trans pro">
                                SPD3303D/S Programmable Linear DC Power Supply                           </a>
                                                        <a href="products-overview/spd3303c/index.html" class="navs trans pro">
                                SPD3303C Programmable Linear DC Power Supply                            </a>
                                            </div>


                </li>
                 <li>

                    <a href="javascript:;" class="bignav">Digital Multimeters</a>
                    <div class="header2">          
                                                    <a href="products-overview/hand-held/index.html" class="navs trans pro">
                                Hand-held Multimeter                            </a>
                                                        <a href="products-overview/bench-top/index.html" class="navs trans pro">
                                Bench-top Multimeterr                            </a>
                                            </div>

                </li>
                 <li>

                    <a href="javascript:;" class="bignav1">Others T & MI </a>
                  
                </li>
                 <li>

                    <a href="javascript:;" class="bignav1">Accessories</a>
               
                </li>
                <li>
                    <a href="about/index.html" class="bignav1">About Us</a>
                   
                </li>
                <li>

                    <a href="partners/index.html" class="bignav">Partners</a>
                    <div class="header2">  
                       <a href="partners/siglent/index.html" class="navs trans pro">
                                Siglent                            </a>
                                                        <a href="partners/twintex/index.html" class="navs trans pro">
                                Twintex                            </a>
                                                        <a href="partners/tonghui/index.html" class="navs trans pro">
                                Tonghui                            </a>
                                                        <a href="partners/maynuo/index.html" class="navs trans pro">
                                Maynuo                         </a>
                                                        <a href="partners/tenmar/index.html" class="navs trans pro">
                                Tenmar
                                                                      </a>     
                    </div>


                </li>
                <li>

                    <a href="careers/index.html" class="bignav1">Careers</a>
               
                </li>
                <li>
                    <a href="news&events/index.html" class="bignav1">News & Events</a>
                   
                </li>
            
            </ul>
        </div>
      <!--   <div class="lan">
            <a href="https://www.siglent.com/?l=1" class="lans trans fl">中国</a>
            <a href="https://siglentna.com/" class="lans trans fr">North America</a>
            <a href="https://www.siglenteu.com/" class="lans trans fl">Europe</a>
            <a href="../../index.html" class="lans trans fr">Other areas</a>
            <div class="clear"></div>
        </div> -->
        <div class="mapss">
            <a href="contact.html" class="maps trans">Contact Us</a>
        </div>
    </div>
</div>
<div id="header-mobile-hidden" class=""></div>
<!-- header-mobile-end -->

<script>
    (function($){ 
    $.fn.hoverDelay = function(options){ 
        var defaults = { 
            hoverDuring: 300, 
            outDuring: 200, 
            hoverEvent: function(){ 
                $.noop(); 
            }, 
            outEvent: function(){ 
                $.noop(); 
            } 
        }; 
        var sets = $.extend(defaults,options || {}); 
        var hoverTimer, outTimer; 
        return $(this).each(function () {
            var me = this;/////////
            $(this).hover(function () {
                clearTimeout(outTimer);
                hoverTimer = setTimeout(function () { if (typeof sets.hoverEvent == 'function') sets.hoverEvent.call(me) }, sets.hoverDuring);
            }, function () {
                clearTimeout(hoverTimer);
                outTimer = setTimeout(function () { if (typeof sets.outEvent == 'function') sets.outEvent.call(me) }, sets.outDuring);
            });
        });
    } 
})(jQuery); 

$(function(){
    $("#header .nav-wrap .nav").hoverDelay({ 
        hoverEvent: function(){ 
            var indexs = $(this).index();
            console.log(indexs);
            $('#header .nav-wraps .nav-menu').eq(indexs).show().siblings('.nav-menu').hide();
        } 
    }); 
})

$(function(){
    // $('#header .nav-wrap .nav').hover(function(){
    //  var indexs = $(this).index();
    //  $('#header .nav-wraps .nav-menu').eq(indexs).show().siblings('.nav-menu').hide();
    // })

    $('#header .nav-wraps').hover(function(){

    },function(){
        $('#header .nav-wraps .nav-menu').hide();
    })
})
</script>			<div class="account-wrap bre">
				<div class="cw1200">
					<!-- bread start -->
<div id="bread">
    <div class="cw1400">
        <span>SWEEYA：</span>
        <a href="index.html" class="trans">Home</a> /
                <a href="contact.html" class="trans">Product Enquiry</a>
                            </div>
</div>
<!-- bread end -->					
<div class="container">  
  <form id="contact" action="mail.php" method="POST">
    <center><h4 style="font-size: 30px;">Product Enquiry</h4></center>

    <fieldset>
      <input type="text" id="name" placeholder="Your Name" name="name" value="" required>
    </fieldset>
    <fieldset>
      <input placeholder="Mobile no" type="text" name="mobile" value="" required>
    </fieldset>
    
    <fieldset>
      <input placeholder="Email" type="email" name="email" value="" required>
    </fieldset>
       
         <h4 class="pro" style="font-size:22px;">
          <?php 

          $product=$_GET['product_name'];

              echo "Product Name : ". $product ."<br>";
          
           ?>
           <input type="hidden" name="product" value="<?php echo $product; ?>">
          <!-- <span name="param1" id="param1">
              <script type="text/javascript">
              document.write(param1)
          </script> 
          </span>-->
            <!-- <p class="groove" id="product"></p></h4> -->
            <!-- <h4>Product Name:<span name="demo"></span></h4> -->
    
      <!-- <input placeholder="Product Name" type="text" id="demo" name="demo" required> -->
    
    <fieldset>
      <textarea placeholder="Your Message"  name="message" value="" tabindex="5" required></textarea>
    </fieldset>
    <fieldset>
      <button type="submit" id="contact-submit">Submit</button>
    </fieldset>
    
  </form>
</div>

	</div>
			</div>
		<!-- <script type="text/javascript">
  function myFunction() {
  var x = localStorage.getItem("name");
  document.getElementById("demo").innerHTML = x;
}
</script> -->	
<!-- footer start -->
<div id="footer">
    <div class="cw1400">
        <div class="footer-wrap">
            <div class="left fl">
                <div class="nav-wrap fl">
                    <div class="title">
                    <img src="images/img13.png">  Call Us                   </div>
                    <div class="nav-row">
                                                                        <a  class="item trans">+91 99861 68404 </a>
                                                                        <a  class="item trans">+91 94816 08404</a>
                                            </div>
                </div>
                                <div class="nav-wrap fl">
                    <div class="title">

                        <img src="images/img14.png"> Address
                    </div>
                    <div class="nav-row">
                        <a  class="item trans">#43/1-1, II Floor, III Main, G. Ramaiah Road, Mathikere, Bengaluru-560054, Karnataka, India</a>
                    
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="mid fl">
                <div class="meg three">
                    <div class="title">
                        Email                   </div>
                    <div class="brief" style="text-transform:lowercase;">
                        sales@sweeyatech.com, <br>sweeya@sweeyatech.com   
                                       </div>
                </div>
            </div>
            <div class="right fr">
                <!-- <div class="font">
                    <div class="title1">
                       SWEEYA TECH SOLUTIONS 
                    </div>
                 
                </div> -->
                <div class="code-row">
                                        <div class="code">
                        <img src="u_file/weblogo/cert.png" alt="cert">
                    </div>
                        
                                    </div>
                
                <div id="drak_big2"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="copyright-wrap">
            <div class="link-wrap">
                                            </div>
            <div class="copyrights">
               <div class="left fl text-left">
                Copyright © 2015 Sweeya Tech Solutions
                <br />
               <!--  <a href="agreement.html" class="item trans">Pravicy Policy</a>
                <a href="terms.html" class="item trans">Terms of Use</a> -->
                <script>
                    var _hmt = _hmt || [];
                    (function() {
                      var hm = document.createElement("script");
                      hm.src = "../hm.baidu.com/hm8c91.js?e8817bd4d93543068412e172849d9189";
                      var s = document.getElementsByTagName("script")[0]; 
                      s.parentNode.insertBefore(hm, s);
                    })();
                </script>
               </div>
               <div class="right fr text-right">
                                                                 </div>
               <div class="clear"></div>
            </div>
        </div>
    </div>
</div>
<!-- footer end -->
<!-- side start -->
<!-- <div id="side">
    <div class="cw1400">
                        <a href="javascript:;" class="sides">
            <div class="img">
                <img src="images/side.png">
            </div>
            <div class="font">
                Contact Us            </div>
        </a>
                                <a href="download/index.html" class="sides2">
            <div class="font">
                Download
            </div>
        </a>
            </div>
</div> -->

<div class="side-main">
    <div class="big trans2">
        <div class="close fl"></div>
        <div class="contact fr">
            <div class="item fl">
                <div class="img">
                    <img src="images/side1.png">
                </div>
                <div class="tit">
                    Tel:
                </div>
                <div class="detail">
                    0755-36887876                </div>
                <div class="clear"></div>
            </div>
            <div class="item fl">
                <div class="img">
                    <img src="images/side2.png">
                </div>
                <div class="tit">
                    E-mail:
                </div>
                <div class="detail">
                    sales@siglent.com                </div>
                <div class="clear"></div>
            </div>
            <div class="item fl">
                <div class="img">
                    <img src="images/side3.png">
                </div>
                <div class="tit">
                    Address:
                </div>
                <div class="detail">
                    Bldg No.4 & No.5, Antongda Industrial Zone, 3rd Liuxian  Road, Bao'an District, Shenzhen, China                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
    </div>
</div>

<script>
    $('.privacy .close').click(function(){
        $('#drak_big2').hide();
        $('.privacy').hide();
    })

    $('.privacy .btn-rows .cancel').click(function(){
        $('#drak_big2').hide();
        $('.privacy').hide();
    })

    $('.privacy .btn-rows .agree').click(function(){
        $('.veification-codes-footer').show();
    })

    $('.veification-codes-footer .big .btnlist .btn1').click(function(){
        $('#footer .footer-wrap .right .email-row form').submit();
    })

    $('.veification-codes-footer .big .btnlist .btn2').click(function(){
        $('.veification-codes-footer').hide();
        $('#drak_big2').hide();
        $('.privacy').hide();
    })

    $('#footer .footer-wrap .right .email-row .submit').click(function(){
        var email_vars = $('#footer .footer-wrap .right .email-row .input').val();
        if(email_vars.match(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/)){
            $('#drak_big2').show();
            $('.privacy').show();
            return false;
        }else{
            alert('Your email is incorrect, please re-enter');
            return false;
        }
    })
</script>		</div>
	</div>
</body>

<!-- Mirrored from int.siglent.com/account.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Apr 2022 07:12:54 GMT -->
</html>

<script>
$(document).ready(function() { 
	var accheight = $('#lib_member .rightContents').height();
	$('#lib_member .leftMenu').height(accheight);
}); 
</script>