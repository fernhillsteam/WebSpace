// public/js/screen-utils.js

(function () {
  let ws;

  // Update the status indicator DOM and persist status in localStorage
  function updateStatusIndicator(status) {
    const indicator = document.querySelector(".status-indicator");
    const text = document.querySelector(".status-text");
    if (indicator && text) {
      if (status === "online") {
        indicator.classList.add("online");
        text.textContent = "Online";
      } else {
        indicator.classList.remove("online");
        text.textContent = "Offline";
      }
    }
    // Save current status so that other pages can immediately show the last known state
    localStorage.setItem("machineStatus", status);
  }

  // Establish the WebSocket connection
  function connectWebSocket() {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}`;
    ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log("✅ WebSocket Connected");
      // Ask server for status
      ws.send("CHECK_STATUS");
      // If a status is stored, update UI immediately
      const storedStatus = localStorage.getItem("machineStatus");
      if (storedStatus) {
        updateStatusIndicator(storedStatus);
      }
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log("WS Message:", data);
        if (data.type === "status" && data.value) {
          updateStatusIndicator(data.value);
        }
        if (data.type === "redirect" && data.value) {
          window.location.href = data.value;
        }
        // Handle other message types if needed…
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };

    ws.onclose = () => {
      console.log("❌ WebSocket Disconnected, retrying in 3 seconds...");
      updateStatusIndicator("offline");
      setTimeout(connectWebSocket, 3000);
    };

    ws.onerror = (error) => {
      console.error("WebSocket Error:", error);
      updateStatusIndicator("offline");
    };
  }

  // Expose the connection function if needed elsewhere
  window.connectWebSocket = connectWebSocket;
  window.getWebSocket = () => ws;

  // Automatically connect when the page loads
  window.addEventListener("load", connectWebSocket);
})();
