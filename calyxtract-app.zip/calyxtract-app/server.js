const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const { SerialPort, ReadlineParser } = require("serialport");
const path = require("path");
const session = require("express-session");

// Create Express App & HTTP Server
const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Set up session middleware
app.use(session({
  secret: "your-secret-key", // change to a secure key for production
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // set secure to true if using HTTPS
}));

// Middleware to parse JSON bodies for POST requests
app.use(express.json());

// Serve Static Files
app.use(express.static(path.join(__dirname, "public")));

// Specific routes for main pages
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "s1.html"));
});
app.get("/s2.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "s2.html"));
});
app.get("/s3.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "s3.html"));
});
app.get("/s4.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "s4.html"));
});

// Endpoint to store chilli selection in session
app.post("/storeSelection", (req, res) => {
  const { variety, image } = req.body;
  if (!variety || !image) {
    return res.status(400).json({ success: false, error: "Missing data" });
  }
  req.session.chilliSelection = { variety, image };
  console.log("Stored session data:", req.session.chilliSelection);
  res.json({ success: true });
});

// Endpoint to fetch stored chilli selection from session
app.get("/chilliData", (req, res) => {
  if (req.session.chilliSelection) {
    console.log("🔍 Fetching session data:", req.session.chilliSelection);
    res.json(req.session.chilliSelection);
  } else {
    console.log("🔍 No session data found. Returning defaults.");
    res.json({ variety: "Unknown", image: "default.png" });
  }
});

// Serial Port Configuration with error handling
let serialPort;
try {
  serialPort = new SerialPort({
    path: "COM1",  // Change this to your actual Serial COM Port if needed
    baudRate: 9600,
    autoOpen: true
  });
  console.log("✅ Serial port opened successfully");
} catch (error) {
  console.error(`❌ Error opening serial port: ${error.message}`);
  process.exit(1);
}

// Create parser for reading serial data
const parser = serialPort.pipe(new ReadlineParser({ delimiter: "\r\n" }));

// Handle serial port errors
serialPort.on("error", (error) => {
  console.error(`❌ Serial Port Error: ${error.message}`);
});

// Global flag to determine if a RUN_MACHINE command is in progress
let runCommandInitiated = false;

// WebSocket Clients List
let clients = [];

// WebSocket Connection Handling
wss.on("connection", (ws) => {
  console.log("🔗 New WebSocket Client Connected.");
  clients.push(ws);
  
  // Send initial status to client
  ws.send(JSON.stringify({ type: "info", value: "Connected to server" }));
  
  ws.on("message", (message) => {
    try {
      message = message.toString().trim();
      console.log("📩 Received from Client:", message);
      console.log("🔍 Current runCommandInitiated flag:", runCommandInitiated);
      
      if (message === "CHECK_STATUS") {
        console.log("🔎 Sending {R} to check status...");
        serialPort.write("{R}", (err) => {
          if (err) {
            console.error(`❌ Error writing {R} to serial port: ${err.message}`);
            ws.send(JSON.stringify({ type: "error", value: "Failed to check status" }));
          }
        });
      }
      
      if (message === "POWER_ON") {
        console.log("⚡ Sending {1} to power on...");
        broadcast({ type: "powering", value: true });
        serialPort.write("{1}", (err) => {
          if (err) {
            console.error(`❌ Error writing {1} to serial port: ${err.message}`);
            ws.send(JSON.stringify({ type: "error", value: "Failed to power on" }));
          } else {
            setTimeout(() => {
              console.log("⏱️ 2 seconds elapsed, sending {S} to serial port...");
              serialPort.write("{S}", (err) => {
                if (err) {
                  console.error(`❌ Error writing {S} to serial port: ${err.message}`);
                } else {
                  console.log("🚀 Sent {S} to serial port, redirecting to s2.html...");
                  broadcast({ type: "redirect", value: "/s2.html" });
                }
              });
            }, 2000);
          }
        });
      }
      
      if (message === "S2_LOADED") {
        console.log("🔄 S2 page loaded, awaiting manual {9} command input...");
        ws.send(JSON.stringify({ type: "info", value: "Please send manual {9} command when ready." }));
      }
      
      if (message === "SEND_9") {
        console.log("🔄 Manual input received: sending {9} to serial port...");
        serialPort.write("{9}", (err) => {
          if (err) {
            console.error(`❌ Error writing {9} to serial port: ${err.message}`);
            ws.send(JSON.stringify({ type: "error", value: "Failed to send manual {9} command" }));
          } else {
            console.log("✅ Sent {9} to serial port successfully");
            broadcast({ type: "status", value: "waiting for {9} acknowledgment" });
          }
        });
      }
      
      if (message === "RUN_MACHINE") {
        console.log("🔄 Received RUN_MACHINE, sending {1} for run command...");
        runCommandInitiated = true;
        console.log("🔍 runCommandInitiated flag set to:", runCommandInitiated);
        serialPort.write("{1}", (err) => {
          if (err) {
            console.error(`❌ Error writing {1} for run command: ${err.message}`);
            ws.send(JSON.stringify({ type: "error", value: "Failed to send {1} for run command" }));
            runCommandInitiated = false;
            console.log("🔍 runCommandInitiated flag reset to:", runCommandInitiated);
          } else {
            console.log("🚀 {1} command sent successfully to serial port for RUN_MACHINE");
            setTimeout(() => {
              console.log("⏱️ 1 second elapsed after sending {1}, sending {SR}...");
              serialPort.write("{SR}", (err) => {
                if (err) {
                  console.error(`❌ Error writing {SR} to serial port: ${err.message}`);
                } else {
                  console.log("🚀 Sent {SR} to serial port successfully, redirecting to s5.html...");
                  broadcast({ type: "redirect", value: "/s5.html" });
                }
              });
              runCommandInitiated = false;
              console.log("🔍 runCommandInitiated flag reset to:", runCommandInitiated);
            }, 1000);
          }
        });
      }
      
      // SHUTDOWN branch:
      if (message === "SHUTDOWN") {
        console.log("🔄 Received SHUTDOWN, sending {ST} for shutdown command...");
        serialPort.write("{ST}", (err) => {
          if (err) {
            console.error(`❌ Error writing {ST} to serial port: ${err.message}`);
            ws.send(JSON.stringify({ type: "error", value: "Failed to send {ST} for shutdown" }));
          } else {
            setTimeout(() => {
              console.log("⏱️ 1 second elapsed after {ST}, sending {DN}...");
              serialPort.write("{DN}", (err) => {
                if (err) {
                  console.error(`❌ Error writing {DN} to serial port: ${err.message}`);
                } else {
                  console.log("🚀 Sent {DN} to serial port successfully, updating status to offline...");
                  broadcast({ type: "status", value: "offline" });
                }
              });
            }, 1000);
          }
        });
      }
      
    } catch (error) {
      console.error(`❌ Error processing client message: ${error.message}`);
    }
  });
  
  ws.on("close", () => {
    console.log("❌ WebSocket Client Disconnected.");
    clients = clients.filter(client => client !== ws);
  });
  
  ws.on("error", (error) => {
    console.error(`❌ WebSocket Error: ${error.message}`);
    clients = clients.filter(client => client !== ws);
  });
});

// Broadcast function to send messages to all connected clients
function broadcast(data) {
  const message = JSON.stringify(data);
  console.log("📣 Broadcasting message:", message);
  clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// Serial data handler
function handleSerialData(data) {
  try {
    const rawData = data.toString();
    const cleanData = rawData.trim();
    console.log("📡 Serial Data Received (raw):", JSON.stringify(rawData));
    console.log("📡 Serial Data Received (clean):", JSON.stringify(cleanData));
    
    if (cleanData === "{0}") {
      console.log("🔄 Received {0}, System is online");
      broadcast({ type: "status", value: "online" });
    }
    
    if (cleanData === "{R}") {
      console.log("🔄 Received {R}, Sending {0}...");
      serialPort.write("{0}", (err) => {
        if (err) console.error(`❌ Error writing {0} to serial port: ${err.message}`);
      });
      broadcast({ type: "status", value: "online" });
    }
    
    // New conditions:
    if (cleanData === "{3}") {
      console.log("✅ Received {3} from serial device, writing {E} back...");
      serialPort.write("{E}", (err) => {
        if (err) console.error(`❌ Error writing {E} to serial port: ${err.message}`);
      });
    }
    
    if (cleanData === "{2}") {
      console.log("✅ Received {2} from serial device, writing {X} back...");
      serialPort.write("{X}", (err) => {
        if (err) console.error(`❌ Error writing {X} to serial port: ${err.message}`);
      });
    }
    
    if (cleanData === "{20}") {
      console.log("✅ Received {20} from serial device, writing {P} back...");
      serialPort.write("{P}", (err) => {
        if (err) console.error(`❌ Error writing {P} to serial port: ${err.message}`);
      });
    }
    
    // Already-existing conditions:
    if (/\{1\}/.test(cleanData)) {
      console.log("✅ Received {1} from serial device");
    }
    
    if (cleanData === "{S}") {
      console.log("🚀 Received {S} from serial device");
      broadcast({ type: "redirect", value: "/s2.html" });
    }
    
    if (cleanData === "{9}") {
      console.log("✅ Received {9} acknowledgment from serial device");
      setTimeout(() => {
        console.log("⏱️ 2 seconds elapsed after {9} acknowledgment, sending {D}...");
        serialPort.write("{D}", (err) => {
          if (err) {
            console.error(`❌ Error writing {D} to serial port: ${err.message}`);
          } else {
            console.log("🚀 Sent {D} to serial port successfully");
            broadcast({ type: "redirect", value: "/s3.html" });
          }
        });
      }, 2000);
    }
    
    if (cleanData === "{D}") {
      console.log("🚀 Received {D} from serial device, redirecting to s3.html");
      broadcast({ type: "redirect", value: "/s3.html" });
    }
  } catch (error) {
    console.error(`❌ Error processing serial data: ${error.message}`);
  }
}

parser.on("data", handleSerialData);

process.on("SIGINT", () => {
  console.log("🛑 Shutting down server...");
  if (serialPort && serialPort.isOpen) {
    serialPort.close();
  }
  server.close(() => {
    console.log("👋 Server closed");
    process.exit(0);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`👉 Open http://localhost:${PORT} in your browser to start`);
});
